(function(){
  'use strict';

  function init(){
    var cards=document.querySelectorAll('.card');
    cards.forEach(function(c,i){
      c.style.transitionDelay=i*60+'ms';
      c.classList.add('card-ready');
    });

    var inp=document.querySelector('.bing-input-wrap');
    if(inp){
      inp.addEventListener('focusin',function(){this.classList.add('focused');});
      inp.addEventListener('focusout',function(){this.classList.remove('focused');});
    }
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',init);
  }else{init();}
})();
